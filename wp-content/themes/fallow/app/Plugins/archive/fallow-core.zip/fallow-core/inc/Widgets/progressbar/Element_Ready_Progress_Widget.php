<?php
namespace Element_Ready_Pro\Widgets\progressbar;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;

use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Modules\DynamicTags\Module as TagsModule;
use Elementor\Utils;
use Elementor\Plugin;
use Elementor\Repeater;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Element_Ready_Progress_Widget extends Widget_Base {

	public function get_name() {
		return 'Element_Ready_Progress_Widget';
	}

	public function get_title() {
		return __( 'ER Progress Bar', 'element-ready-pro' );
	}

	public function get_icon() {
		return 'eicon-skill-bar';
	}

	public function get_categories() {
		return array('element-ready-pro');
	}

    public function get_keywords() {
        return [ 'skill', 'progress', 'progressbar', 'skill bar' ];
    }

	public function get_script_depends() {

		return[
			'easyBar',
		    'element-ready-core',
		];
	}

	public function get_style_depends() {
		
		return[
			'easyBar',
		];
	}

	public static function content_layout_style(){
		return [
			'stiky__postion__left'   => 'Button Style 1',
			'stiky__postion__right'  => 'Button Style 2',
			'stiky__postion__custom' => 'Custom Style',
		];
	}

	protected function register_controls() {

		/******************************
		 * 	CONTENT SECTION
		 ******************************/
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'element-ready-pro' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
			$this->add_control(
				'content_layout_style',
				[
					'label'     => __( 'Sticky Position', 'element-ready-pro' ),
					'type'      => Controls_Manager::SELECT,
					'default'   => 'stiky__postion__right',
					'options'   => self::content_layout_style(),
					'condition' => [
						'example' => 'yes',
					],
				]
			);

			$this->add_control(
				'show_title',
				[
					'label'        => __( 'Show Title', 'element-ready-pro' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Show', 'element-ready-pro' ),
					'label_off'    => __( 'Hide', 'element-ready-pro' ),
					'return_value' => 'yes',
					'default'      => 'yes',
				]
			);
			$this->add_control(
				'title',
				[
					'label'         => __( 'Progressbar Title', 'element-ready-pro' ),
					'type'          => Controls_Manager::TEXT,
					'show_external' => true,
					'default'       => 'This is title',
					'condition'     => [
						'show_title' => 'yes',
					],
				]
			);
			$this->add_control(
				'percentage',
				[
					'label'      => __( 'Progressbar Percentage', 'element-ready-pro' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => [ '%' ],
					'range'      => [
						'%' => [
							'min'  => 0,
							'max'  => 100,
							'step' => 1,
						],
					],
					'default' => [
						'unit' => '%',
						'size' => 70,
					],
					'separator' => 'before',
				]
			);
			$this->add_control(
				'height',
				[
					'label'      => __( 'Progressbar Height', 'element-ready-pro' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range'      => [
						'%' => [
							'min'  => 1,
							'max'  => 100,
							'step' => 1,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 20,
					],
					'separator' => 'before',
				]
			);
			$this->add_control(
				'radius',
				[
					'label'      => __( 'Progressbar Radius', 'element-ready-pro' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range'      => [
						'%' => [
							'min'  => 0,
							'max'  => 100,
							'step' => 1,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 0,
					],
					'separator' => 'before',
				]
			);
			$this->add_control(
				'unit',
				[
					'label'   => __( 'Progressbar Unit', 'element-ready-pro' ),
					'type'    => Controls_Manager::SELECT,
					'default' => '%',
					'options' => [
						'%'    => __('%', 'element-ready-pro'),
						'km/h' => __('km/h', 'element-ready-pro'),
						'm/s'  => __('m/s', 'element-ready-pro'),
						'Km'   => __('Km', 'element-ready-pro'),
						'HP'   => __('HP', 'element-ready-pro'),
					],
					'separator' => 'before',
				]
			);

			$this->add_control(
				'ShowProgressCount',
				[
					'label'        => __( 'Show Progress Count', 'element-ready-pro' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Show', 'element-ready-pro' ),
					'label_off'    => __( 'Hide', 'element-ready-pro' ),
					'return_value' => 'yes',
					'default'      => 'yes',
					'separator'    => 'before',
				]
			);

			$this->add_control(
				'animation',
				[
					'label'        => __( 'Animation ?', 'element-ready-pro' ),
					'type'         => Controls_Manager::SWITCHER,
					'label_on'     => __( 'Show', 'element-ready-pro' ),
					'label_off'    => __( 'Hide', 'element-ready-pro' ),
					'return_value' => 'yes',
					'default'      => 'yes',
					'separator'    => 'before',
				]
			);
			$this->add_control(
				'duration',
				[
					'label'      => __( 'Animation Duration', 'element-ready-pro' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range'      => [
						'px' => [
							'min'  => 100,
							'max'  => 10000,
							'step' => 100,
						],
					],
					'default' => [
						'unit' => 'px',
						'size' => 1000,
					],
					'separator' => 'before',
				]
			);
			$this->add_control(
				'fillBackgroundColor',
				[
					'label'     => __( 'Progress Fill Color', 'element-ready-pro' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#3498db',
					'separator' => 'before',
				]
			);
			$this->add_control(
				'backgroundColor',
				[
					'label'     => __( 'Background Fill Color', 'element-ready-pro' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '#EEEEEE',
					'separator' => 'before',
				]
			);
		$this->end_controls_section();
		/*******************************
		 * 	ONTE SECTION END
		 *******************************/

		/*----------------------------
			PROGRESSBAR TITLE
		-----------------------------*/
		$this->start_controls_section(
			'title_style_section',
			[
				'label' => __( 'Title', 'element-ready-pro' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'show_title' => 'yes',
				],
			]
		);
			// Typgraphy
			$this->add_group_control(
				Group_Control_Typography:: get_type(),
				[
					'name'      => 'title_typography',
					'selector'  => '{{WRAPPER}} .progressTitle',
				]
			);

			// Icon Color
			$this->add_control(
				'title_color',
				[
					'label'     => __( 'Color', 'element-ready-pro' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '',
					'selectors' => [
						'{{WRAPPER}} .progressTitle' => 'color: {{VALUE}};',
					],
				]
			);

			// Background
			$this->add_group_control(
				Group_Control_Background:: get_type(),
				[
					'name'     => 'title_background',
					'label'    => __( 'Background', 'element-ready-pro' ),
					'types'    => [ 'classic', 'gradient' ],
					'selector' => '{{WRAPPER}} .progressTitle',
				]
			);

			// Border
			$this->add_group_control(
				Group_Control_Border:: get_type(),
				[
					'name'     => 'title_border',
					'label'    => __( 'Border', 'element-ready-pro' ),
					'selector' => '{{WRAPPER}} .progressTitle',
					'separator' => 'before',
				]
			);

			// Radius
			$this->add_responsive_control(
				'title_radius',
				[
					'label'      => __( 'Border Radius', 'element-ready-pro' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors'  => [
						'{{WRAPPER}} .progressTitle' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			
			// Shadow
			$this->add_group_control(
				Group_Control_Box_Shadow:: get_type(),
				[
					'name'     => 'title_shadow',
					'selector' => '{{WRAPPER}} .progressTitle',
				]
			);

			// Width
			$this->add_responsive_control(
				'title_width',
				[
					'label'      => __( 'Width', 'element-ready-pro' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range'      => [
						'px' => [
							'min'  => 0,
							'max'  => 1000,
							'step' => 1,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => 'px',
					],
					'selectors' => [
						'{{WRAPPER}} .progressTitle' => 'width: {{SIZE}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);

			// Height
			$this->add_responsive_control(
				'title_height',
				[
					'label'      => __( 'Height', 'element-ready-pro' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range'      => [
						'px' => [
							'min'  => 0,
							'max'  => 1000,
							'step' => 1,
						],
						'%' => [
							'min' => 0,
						],
					],
					'default' => [
						'unit' => 'px',
					],
					'selectors' => [
						'{{WRAPPER}} .progressTitle' => 'height: {{SIZE}}{{UNIT}};',
					],
				]
			);

			// Margin
			$this->add_responsive_control(
				'title_margin',
				[
					'label'      => __( 'Margin', 'element-ready-pro' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors'  => [
						'{{WRAPPER}} .progressTitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);

			// Padding
			$this->add_responsive_control(
				'title_padding',
				[
					'label'      => __( 'Padding', 'element-ready-pro' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors'  => [
						'{{WRAPPER}} .progressTitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();
		/*----------------------------
			PROGRESSBAR TITLE END
		-----------------------------*/

		/*----------------------------
			PROGRESS COUNT STYLE
		-----------------------------*/
		$this->start_controls_section(
			'prgress_count_style_section',
			[
				'label' => __( 'Progress Count', 'element-ready-pro' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
			// Typgraphy
			$this->add_group_control(
				Group_Control_Typography:: get_type(),
				[
					'name'      => 'prgress_count_typography',
					'selector'  => '{{WRAPPER}} .percentCount',
				]
			);

			// Icon Color
			$this->add_control(
				'prgress_count_color',
				[
					'label'     => __( 'Color', 'element-ready-pro' ),
					'type'      => Controls_Manager::COLOR,
					'default'   => '',
					'selectors' => [
						'{{WRAPPER}} .percentCount' => 'color: {{VALUE}};',
					],
				]
			);

			// Background
			$this->add_group_control(
				Group_Control_Background:: get_type(),
				[
					'name'     => 'prgress_count_background',
					'label'    => __( 'Background', 'element-ready-pro' ),
					'types'    => [ 'classic', 'gradient' ],
					'selector' => '{{WRAPPER}} .percentCount',
				]
			);

			// Border
			$this->add_group_control(
				Group_Control_Border:: get_type(),
				[
					'name'     => 'prgress_count_border',
					'label'    => __( 'Border', 'element-ready-pro' ),
					'selector' => '{{WRAPPER}} .percentCount',
					'separator' => 'before',
				]
			);

			// Radius
			$this->add_responsive_control(
				'prgress_count_radius',
				[
					'label'      => __( 'Border Radius', 'element-ready-pro' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors'  => [
						'{{WRAPPER}} .percentCount' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			
			// Shadow
			$this->add_group_control(
				Group_Control_Box_Shadow:: get_type(),
				[
					'name'     => 'prgress_count_shadow',
					'selector' => '{{WRAPPER}} .percentCount',
				]
			);

			// Width
			$this->add_responsive_control(
				'prgress_count_width',
				[
					'label'      => __( 'Width', 'element-ready-pro' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range'      => [
						'px' => [
							'min'  => 0,
							'max'  => 1000,
							'step' => 1,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => 'px',
					],
					'selectors' => [
						'{{WRAPPER}} .percentCount' => 'width: {{SIZE}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);

			// Height
			$this->add_responsive_control(
				'prgress_count_height',
				[
					'label'      => __( 'Height', 'element-ready-pro' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range'      => [
						'px' => [
							'min'  => 0,
							'max'  => 1000,
							'step' => 1,
						],
						'%' => [
							'min' => 0,
						],
					],
					'default' => [
						'unit' => 'px',
					],
					'selectors' => [
						'{{WRAPPER}} .percentCount' => 'height: {{SIZE}}{{UNIT}};',
					],
				]
			);

			// Margin
			$this->add_responsive_control(
				'prgress_count_margin',
				[
					'label'      => __( 'Margin', 'element-ready-pro' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors'  => [
						'{{WRAPPER}} .percentCount' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);

			// Padding
			$this->add_responsive_control(
				'prgress_count_padding',
				[
					'label'      => __( 'Padding', 'element-ready-pro' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors'  => [
						'{{WRAPPER}} .percentCount' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();
		/*----------------------------
			PROGRESS COUNT STYLE END
		-----------------------------*/

		/*----------------------------
			PROGRESS STYLE
		-----------------------------*/
		$this->start_controls_section(
			'progress_style_section',
			[
				'label' => __( 'Progress Style', 'element-ready-pro' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'progress_background',
				[
					'label'     => __( 'Background Color', 'element-ready-pro' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .element__ready__progressbar__activation .proggress' => 'background: {{VALUE}} !important;',
					],
				]
			);
			$this->add_group_control(
				Group_Control_Border:: get_type(),
				[
					'name'     => 'progress_border',
					'label'    => __( 'Border', 'element-ready-pro' ),
					'selector' => '{{WRAPPER}} .element__ready__progressbar__activation .proggress',
					'separator' => 'before',
				]
			);
			$this->add_responsive_control(
				'progress_radius',
				[
					'label'      => __( 'Border Radius', 'element-ready-pro' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors'  => [
						'{{WRAPPER}} .element__ready__progressbar__activation .proggress' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
					],
				]
			);
			$this->add_group_control(
				Group_Control_Box_Shadow:: get_type(),
				[
					'name'     => 'progress_shadow',
					'selector' => '{{WRAPPER}} .element__ready__progressbar__activation .proggress',
				]
			);
			$this->add_responsive_control(
				'progress_width',
				[
					'label'      => __( 'Width', 'element-ready-pro' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range'      => [
						'px' => [
							'min'  => 0,
							'max'  => 1000,
							'step' => 1,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => 'px',
					],
					'selectors' => [
						'{{WRAPPER}} .element__ready__progressbar__activation .proggress' => 'width: {{SIZE}}{{UNIT}} !important;',
					],
					'separator' => 'before',
				]
			);
			$this->add_responsive_control(
				'progress_height',
				[
					'label'      => __( 'Height', 'element-ready-pro' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range'      => [
						'px' => [
							'min'  => 0,
							'max'  => 1000,
							'step' => 1,
						],
						'%' => [
							'min' => 0,
						],
					],
					'default' => [
						'unit' => 'px',
					],
					'selectors' => [
						'{{WRAPPER}} .element__ready__progressbar__activation .proggress' => 'height: {{SIZE}}{{UNIT}} !important;',
					],
				]
			);
			$this->add_responsive_control(
				'progress_margin',
				[
					'label'      => __( 'Margin', 'element-ready-pro' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors'  => [
						'{{WRAPPER}} .element__ready__progressbar__activation .proggress' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
		$this->end_controls_section();
		/*----------------------------
			PROGRESS STYLE END
		-----------------------------*/

		/*----------------------------
			PROGRESSBAR WRAP STYLE
		-----------------------------*/
		$this->start_controls_section(
			'progressbar_wrap_style_section',
			[
				'label' => __( 'Progressbar Wrap', 'element-ready-pro' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'progressbar_wrap_background',
				[
					'label'     => __( 'Background Color', 'element-ready-pro' ),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .element__ready__progressbar__activation .progressbar' => 'background: {{VALUE}} !important;',
					],
				]
			);
			$this->add_group_control(
				Group_Control_Border:: get_type(),
				[
					'name'     => 'progressbar_wrap_border',
					'label'    => __( 'Border', 'element-ready-pro' ),
					'selector' => '{{WRAPPER}} .element__ready__progressbar__activation .progressbar',
					'separator' => 'before',
				]
			);
			$this->add_responsive_control(
				'progressbar_wrap_radius',
				[
					'label'      => __( 'Border Radius', 'element-ready-pro' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors'  => [
						'{{WRAPPER}} .element__ready__progressbar__activation .progressbar' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
					],
				]
			);
			$this->add_group_control(
				Group_Control_Box_Shadow:: get_type(),
				[
					'name'     => 'progressbar_wrap_shadow',
					'selector' => '{{WRAPPER}} .element__ready__progressbar__activation .progressbar',
				]
			);
			$this->add_responsive_control(
				'progressbar_wrap_width',
				[
					'label'      => __( 'Width', 'element-ready-pro' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range'      => [
						'px' => [
							'min'  => 0,
							'max'  => 1000,
							'step' => 1,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => 'px',
					],
					'selectors' => [
						'{{WRAPPER}} .element__ready__progressbar__activation .progressbar' => 'width: {{SIZE}}{{UNIT}} !important;',
					],
					'separator' => 'before',
				]
			);
			$this->add_responsive_control(
				'progressbar_wrap_height',
				[
					'label'      => __( 'Height', 'element-ready-pro' ),
					'type'       => Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range'      => [
						'px' => [
							'min'  => 0,
							'max'  => 1000,
							'step' => 1,
						],
						'%' => [
							'min' => 0,
						],
					],
					'default' => [
						'unit' => 'px',
					],
					'selectors' => [
						'{{WRAPPER}} .element__ready__progressbar__activation .progressbar' => 'height: {{SIZE}}{{UNIT}} !important;',
					],
				]
			);
			$this->add_responsive_control(
				'progressbar_wrap_margin',
				[
					'label'      => __( 'Margin', 'element-ready-pro' ),
					'type'       => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%', 'em' ],
					'selectors'  => [
						'{{WRAPPER}} .element__ready__progressbar__activation .progressbar' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
		$this->end_controls_section();
		/*----------------------------
			PROGRESSBAR WRAP STYLE END
		-----------------------------*/

			/*----------------------------
			BOX BEFORE / AFTER
		-----------------------------*/
		$this->start_controls_section(
			'progressbar_box__before_after_style_section',
			[
				'label' => __( 'Progressbar Before / After', 'element-ready-pro' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				
			]
		);
			$this->start_controls_tabs( 'progressbar_box__before_after_tab_style' );
				$this->start_controls_tab(
					'progressbar_box__before_tab',
					[
						'label' => __( 'BEFORE', 'element-ready-pro' ),
					]
				);

					$this->add_control(
						'progressbar_box__before_content',
						[
							'label' => __( 'Content', 'element-ready-pro' ),
							'type' => \Elementor\Controls_Manager::TEXT,
							'default' => '\0 ',
							'placeholder' => __( 'Type your content here', 'element-ready-pro' ),
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::before' => 'content: " ";',
							],
						]
					);
 

					$this->add_group_control(
						Group_Control_Background:: get_type(),
						[
							'name'     => 'progressbar_box__before_background',
							'label'    => __( 'Background', 'element-ready-pro' ),
							'types'    => [ 'classic', 'gradient' ],
							'selector' => '{{WRAPPER}} .element__ready__progressbar__activation .progressbar::before',
						]
					);
					$this->add_responsive_control(
						'progressbar_box__before_display',
						[
							'label'   => __( 'Display', 'element-ready-pro' ),
							'type'    => Controls_Manager::SELECT,
							'default' => '',
							'options' => [
								'initial'      => __( 'Initial', 'element-ready-pro' ),
								'block'        => __( 'Block', 'element-ready-pro' ),
								'inline-block' => __( 'Inline Block', 'element-ready-pro' ),
								'flex'         => __( 'Flex', 'element-ready-pro' ),
								'inline-flex'  => __( 'Inline Flex', 'element-ready-pro' ),
								'none'         => __( 'none', 'element-ready-pro' ),
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::before' => 'display: {{VALUE}};',
							],
						]
					);

					$this->add_responsive_control(
						'progressbar_box__before_position',
						[
							'label'   => __( 'Position', 'element-ready-pro' ),
							'type'    => Controls_Manager::SELECT,
							'default' => '',				
							'options' => [
								'initial'  => __( 'Initial', 'element-ready-pro' ),
								'absolute' => __( 'Absulute', 'element-ready-pro' ),
								'relative' => __( 'Relative', 'element-ready-pro' ),
								'static'   => __( 'Static', 'element-ready-pro' ),
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::before' => 'position: {{VALUE}};',
							],
						]
					);
					$this->add_responsive_control(
						'progressbar_box__before_position_from_left',
						[
							'label'      => __( 'From Left', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::before' => 'left: {{SIZE}}{{UNIT}};',
							],
							'condition' => [
								'progressbar_box__before_position' => ['absolute','relative']
							],
						]
					);
					$this->add_responsive_control(
						'progressbar_box__before_position_from_right',
						[
							'label'      => __( 'From Right', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::before' => 'right: {{SIZE}}{{UNIT}};',
							],
							'condition' => [
								'progressbar_box__before_position' => ['absolute','relative']
							],
						]
					);
					$this->add_responsive_control(
						'progressbar_box__before_position_from_top',
						[
							'label'      => __( 'From Top', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::before' => 'top: {{SIZE}}{{UNIT}};',
							],
							'condition' => [
								'progressbar_box__before_position' => ['absolute','relative']
							],
						]
					);
					$this->add_responsive_control(
						'progressbar_box__before_position_from_bottom',
						[
							'label'      => __( 'From Bottom', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::before' => 'bottom: {{SIZE}}{{UNIT}};',
							],
							'condition' => [
								'progressbar_box__before_position' => ['absolute','relative']
							],
						]
					);
					$this->add_responsive_control(
						'progressbar_box__before_align',
						[
							'label'   => __( 'Alignment', 'element-ready-pro' ),
							'type'    => Controls_Manager::CHOOSE,
							'options' => [
								'text-align:left' => [
									'title' => __( 'Left', 'element-ready-pro' ),
									'icon'  => 'fa fa-align-left',
								],
								'margin: 0 auto' => [
									'title' => __( 'Center', 'element-ready-pro' ),
									'icon'  => 'fa fa-align-center',
								],
								'float:right' => [
									'title' => __( 'Right', 'element-ready-pro' ),
									'icon'  => 'fa fa-align-right',
								],
								'text-align:justify' => [
									'title' => __( 'Justify', 'element-ready-pro' ),
									'icon'  => 'fa fa-align-justify',
								],
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::before' => '{{VALUE}};',
							],
							'default' => 'text-align:left',
						]
					);
					$this->add_responsive_control(
						'progressbar_box__before_width',
						[
							'label'      => __( 'Width', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::before' => 'width: {{SIZE}}{{UNIT}};',
							],
						]
					);
					$this->add_responsive_control(
						'progressbar_box__before_height',
						[
							'label'      => __( 'Height', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::before' => 'height: {{SIZE}}{{UNIT}};',
							],
						]
					);
					$this->add_control(
						'progressbar_box__before_opacity',
						[
							'label' => __( 'Opacity', 'element-ready-pro' ),
							'type'  => Controls_Manager::SLIDER,
							'range' => [
								'px' => [
									'max'  => 1,
									'min'  => 0.10,
									'step' => 0.01,
								],
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::before' => 'opacity: {{SIZE}};',
							],
						]
					);
					$this->add_control(
						'progressbar_box__before_zindex',
						[
							'label'     => __( 'Z-Index', 'element-ready-pro' ),
							'type'      => Controls_Manager::NUMBER,
							'min'       => -99,
							'max'       => 99,
							'step'      => 1,
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::before' => 'z-index: {{SIZE}};',
							],
						]
					);
					$this->add_responsive_control(
						'progressbar_box__before_margin',
						[
							'label'      => __( 'Margin', 'element-ready-pro' ),
							'type'       => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%', 'em' ],
							'selectors'  => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::before' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
					$this->add_responsive_control(
						'progressbar_box__before_border_radius',
						[
							'label'      => __( 'Border  Radius', 'element-ready-pro' ),
							'type'       => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%', 'em' ],
							'selectors'  => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
				$this->end_controls_tab();
				$this->start_controls_tab(
					'progressbar_box__after_tab',
					[
						'label' => __( 'AFTER', 'element-ready-pro' ),
					]
				);

					$this->add_control(
						'progressbar_box__after_content',
						[
							'label' => __( 'Content', 'element-ready-pro' ),
							'type' => \Elementor\Controls_Manager::TEXT,
							'default' => '\0 ',
							'placeholder' => __( 'Type your content here', 'element-ready-pro' ),
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::after' => 'content: " "',
							],
						]
					);

                
					$this->add_group_control(
						Group_Control_Background:: get_type(),
						[
							'name'     => 'progressbar_box__after_background',
							'label'    => __( 'Background', 'element-ready-pro' ),
							'types'    => [ 'classic', 'gradient' ],
							'selector' => '{{WRAPPER}} .element__ready__progressbar__activation .progressbar::after',
						]
					);
					$this->add_responsive_control(
						'progressbar_box__after_display',
						[
							'label'   => __( 'Display', 'element-ready-pro' ),
							'type'    => Controls_Manager::SELECT,
							'default' => '',
							'options' => [
								'initial'      => __( 'Initial', 'element-ready-pro' ),
								'block'        => __( 'Block', 'element-ready-pro' ),
								'inline-block' => __( 'Inline Block', 'element-ready-pro' ),
								'flex'         => __( 'Flex', 'element-ready-pro' ),
								'inline-flex'  => __( 'Inline Flex', 'element-ready-pro' ),
								'none'         => __( 'none', 'element-ready-pro' ),
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::after' => 'display: {{VALUE}};content:" ";',
							],
						]
					);
					$this->add_responsive_control(
						'progressbar_box__after_position',
						[
							'label'   => __( 'Position', 'element-ready-pro' ),
							'type'    => Controls_Manager::SELECT,
							'default' => '',
							
							'options' => [
								'initial'  => __( 'Initial', 'element-ready-pro' ),
								'absolute' => __( 'Absulute', 'element-ready-pro' ),
								'relative' => __( 'Relative', 'element-ready-pro' ),
								'static'   => __( 'Static', 'element-ready-pro' ),
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::after' => 'position: {{VALUE}};',
							],
						]
					);
					$this->add_responsive_control(
						'progressbar_box__after_position_from_left',
						[
							'label'      => __( 'From Left', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::after' => 'left: {{SIZE}}{{UNIT}};',
							],
							'condition' => [
								'progressbar_box__after_position' => ['absolute','relative']
							],
						]
					);
					$this->add_responsive_control(
						'progressbar_box__after_position_from_right',
						[
							'label'      => __( 'From Right', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::after' => 'right: {{SIZE}}{{UNIT}};',
							],
							'condition' => [
								'progressbar_box__after_position' => ['absolute','relative']
							],
						]
					);
					$this->add_responsive_control(
						'progressbar_box__after_position_from_top',
						[
							'label'      => __( 'From Top', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::after' => 'top: {{SIZE}}{{UNIT}};',
							],
							'condition' => [
								'progressbar_box__after_position' => ['absolute','relative']
							],
						]
					);
					$this->add_responsive_control(
						'progressbar_box__after_position_from_bottom',
						[
							'label'      => __( 'From Bottom', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::after' => 'bottom: {{SIZE}}{{UNIT}};',
							],
							'condition' => [
								'progressbar_box__after_position' => ['absolute','relative']
							],
						]
					);
					$this->add_responsive_control(
						'progressbar_box__after_align',
						[
							'label'   => __( 'Alignment', 'element-ready-pro' ),
							'type'    => Controls_Manager::CHOOSE,
							'options' => [
								'text-align:left' => [
									'title' => __( 'Left', 'element-ready-pro' ),
									'icon'  => 'fa fa-align-left',
								],
								'margin: 0 auto' => [
									'title' => __( 'Center', 'element-ready-pro' ),
									'icon'  => 'fa fa-align-center',
								],
								'float:right' => [
									'title' => __( 'Right', 'element-ready-pro' ),
									'icon'  => 'fa fa-align-right',
								],
								'text-align:justify' => [
									'title' => __( 'Justify', 'element-ready-pro' ),
									'icon'  => 'fa fa-align-justify',
								],
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::after' => '{{VALUE}};',
							],
							'default' => 'text-align:left',
						]
					);
					$this->add_responsive_control(
						'progressbar_box__after_width',
						[
							'label'      => __( 'Width', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::after' => 'width: {{SIZE}}{{UNIT}};',
							],
						]
					);
					$this->add_responsive_control(
						'progressbar_box__after_height',
						[
							'label'      => __( 'Height', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::after' => 'height: {{SIZE}}{{UNIT}};',
							],
						]
					);
					$this->add_control(
						'progressbar_box__after_opacity',
						[
							'label' => __( 'Opacity', 'element-ready-pro' ),
							'type'  => Controls_Manager::SLIDER,
							'range' => [
								'px' => [
									'max'  => 1,
									'min'  => 0.10,
									'step' => 0.01,
								],
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::after' => 'opacity: {{SIZE}};',
							],
						]
					);
					$this->add_control(
						'progressbar_box__after_zindex',
						[
							'label'     => __( 'Z-Index', 'element-ready-pro' ),
							'type'      => Controls_Manager::NUMBER,
							'min'       => -99,
							'max'       => 99,
							'step'      => 1,
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::after' => 'z-index: {{SIZE}};',
							],
						]
					);
					$this->add_responsive_control(
						'progressbar_box__after_margin',
						[
							'label'      => __( 'Margin', 'element-ready-pro' ),
							'type'       => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%', 'em' ],
							'selectors'  => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::after' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);

					$this->add_responsive_control(
						'progressbar_box__after_border__radius',
						[
							'label'      => __( 'Border Radius', 'element-ready-pro' ),
							'type'       => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%', 'em' ],
							'selectors'  => [
								'{{WRAPPER}} .element__ready__progressbar__activation .progressbar::after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);

				$this->end_controls_tab();
			$this->end_controls_tabs();
		$this->end_controls_section();

		$this->start_controls_section(
			'progress_box__before_after_style_section',
			[
				'label' => __( 'Progress Before / After', 'element-ready-pro' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				
			]
		);
			$this->start_controls_tabs( 'progress_box__before_after_tab_style' );
				$this->start_controls_tab(
					'progress_box__before_tab',
					[
						'label' => __( 'BEFORE', 'element-ready-pro' ),
					]
				);

					$this->add_control(
						'progress_box__before_content',
						[
							'label' => __( 'Content', 'element-ready-pro' ),
							'type' => \Elementor\Controls_Manager::TEXT,
							'default' => '\0 ',
							'placeholder' => __( 'Type your content here', 'element-ready-pro' ),
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::before' => 'content: " ";',
							],
						]
					);
 

					$this->add_group_control(
						Group_Control_Background:: get_type(),
						[
							'name'     => 'progress_box__before_background',
							'label'    => __( 'Background', 'element-ready-pro' ),
							'types'    => [ 'classic', 'gradient' ],
							'selector' => '{{WRAPPER}} .element__ready__progressbar__activation .proggress::before',
						]
					);
					$this->add_responsive_control(
						'progress_box__before_display',
						[
							'label'   => __( 'Display', 'element-ready-pro' ),
							'type'    => Controls_Manager::SELECT,
							'default' => '',
							'options' => [
								'initial'      => __( 'Initial', 'element-ready-pro' ),
								'block'        => __( 'Block', 'element-ready-pro' ),
								'inline-block' => __( 'Inline Block', 'element-ready-pro' ),
								'flex'         => __( 'Flex', 'element-ready-pro' ),
								'inline-flex'  => __( 'Inline Flex', 'element-ready-pro' ),
								'none'         => __( 'none', 'element-ready-pro' ),
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::before' => 'display: {{VALUE}};',
							],
						]
					);

					$this->add_responsive_control(
						'progress_box__before_position',
						[
							'label'   => __( 'Position', 'element-ready-pro' ),
							'type'    => Controls_Manager::SELECT,
							'default' => '',				
							'options' => [
								'initial'  => __( 'Initial', 'element-ready-pro' ),
								'absolute' => __( 'Absulute', 'element-ready-pro' ),
								'relative' => __( 'Relative', 'element-ready-pro' ),
								'static'   => __( 'Static', 'element-ready-pro' ),
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::before' => 'position: {{VALUE}};',
							],
						]
					);
					$this->add_responsive_control(
						'progress_box__before_position_from_left',
						[
							'label'      => __( 'From Left', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::before' => 'left: {{SIZE}}{{UNIT}};',
							],
							'condition' => [
								'progress_box__before_position' => ['absolute','relative']
							],
						]
					);
					$this->add_responsive_control(
						'progress_box__before_position_from_right',
						[
							'label'      => __( 'From Right', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::before' => 'right: {{SIZE}}{{UNIT}};',
							],
							'condition' => [
								'progress_box__before_position' => ['absolute','relative']
							],
						]
					);
					$this->add_responsive_control(
						'progress_box__before_position_from_top',
						[
							'label'      => __( 'From Top', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::before' => 'top: {{SIZE}}{{UNIT}};',
							],
							'condition' => [
								'progress_box__before_position' => ['absolute','relative']
							],
						]
					);
					$this->add_responsive_control(
						'progress_box__before_position_from_bottom',
						[
							'label'      => __( 'From Bottom', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::before' => 'bottom: {{SIZE}}{{UNIT}};',
							],
							'condition' => [
								'progress_box__before_position' => ['absolute','relative']
							],
						]
					);
					$this->add_responsive_control(
						'progress_box__before_align',
						[
							'label'   => __( 'Alignment', 'element-ready-pro' ),
							'type'    => Controls_Manager::CHOOSE,
							'options' => [
								'text-align:left' => [
									'title' => __( 'Left', 'element-ready-pro' ),
									'icon'  => 'fa fa-align-left',
								],
								'margin: 0 auto' => [
									'title' => __( 'Center', 'element-ready-pro' ),
									'icon'  => 'fa fa-align-center',
								],
								'float:right' => [
									'title' => __( 'Right', 'element-ready-pro' ),
									'icon'  => 'fa fa-align-right',
								],
								'text-align:justify' => [
									'title' => __( 'Justify', 'element-ready-pro' ),
									'icon'  => 'fa fa-align-justify',
								],
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::before' => '{{VALUE}};',
							],
							'default' => 'text-align:left',
						]
					);
					$this->add_responsive_control(
						'progress_box__before_width',
						[
							'label'      => __( 'Width', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::before' => 'width: {{SIZE}}{{UNIT}};',
							],
						]
					);
					$this->add_responsive_control(
						'progress_box__before_height',
						[
							'label'      => __( 'Height', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::before' => 'height: {{SIZE}}{{UNIT}};',
							],
						]
					);
					$this->add_control(
						'progress_box__before_opacity',
						[
							'label' => __( 'Opacity', 'element-ready-pro' ),
							'type'  => Controls_Manager::SLIDER,
							'range' => [
								'px' => [
									'max'  => 1,
									'min'  => 0.10,
									'step' => 0.01,
								],
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::before' => 'opacity: {{SIZE}};',
							],
						]
					);
					$this->add_control(
						'progress_box__before_zindex',
						[
							'label'     => __( 'Z-Index', 'element-ready-pro' ),
							'type'      => Controls_Manager::NUMBER,
							'min'       => -99,
							'max'       => 99,
							'step'      => 1,
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::before' => 'z-index: {{SIZE}};',
							],
						]
					);
					$this->add_responsive_control(
						'progress_box__before_margin',
						[
							'label'      => __( 'Margin', 'element-ready-pro' ),
							'type'       => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%', 'em' ],
							'selectors'  => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::before' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
					$this->add_responsive_control(
						'progress_box__before_border_radius',
						[
							'label'      => __( 'Border  Radius', 'element-ready-pro' ),
							'type'       => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%', 'em' ],
							'selectors'  => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
				$this->end_controls_tab();
				$this->start_controls_tab(
					'progress_box__after_tab',
					[
						'label' => __( 'AFTER', 'element-ready-pro' ),
					]
				);

					$this->add_control(
						'progress_box__after_content',
						[
							'label' => __( 'Content', 'element-ready-pro' ),
							'type' => \Elementor\Controls_Manager::TEXT,
							'default' => '\0 ',
							'placeholder' => __( 'Type your content here', 'element-ready-pro' ),
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::after' => 'content: " "',
							],
						]
					);

                
					$this->add_group_control(
						Group_Control_Background:: get_type(),
						[
							'name'     => 'progress_box__after_background',
							'label'    => __( 'Background', 'element-ready-pro' ),
							'types'    => [ 'classic', 'gradient' ],
							'selector' => '{{WRAPPER}} .element__ready__progressbar__activation .proggress::after',
						]
					);
					$this->add_responsive_control(
						'progress_box__after_display',
						[
							'label'   => __( 'Display', 'element-ready-pro' ),
							'type'    => Controls_Manager::SELECT,
							'default' => '',
							'options' => [
								'initial'      => __( 'Initial', 'element-ready-pro' ),
								'block'        => __( 'Block', 'element-ready-pro' ),
								'inline-block' => __( 'Inline Block', 'element-ready-pro' ),
								'flex'         => __( 'Flex', 'element-ready-pro' ),
								'inline-flex'  => __( 'Inline Flex', 'element-ready-pro' ),
								'none'         => __( 'none', 'element-ready-pro' ),
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::after' => 'display: {{VALUE}};content:" ";',
							],
						]
					);
					$this->add_responsive_control(
						'progress_box__after_position',
						[
							'label'   => __( 'Position', 'element-ready-pro' ),
							'type'    => Controls_Manager::SELECT,
							'default' => '',
							
							'options' => [
								'initial'  => __( 'Initial', 'element-ready-pro' ),
								'absolute' => __( 'Absulute', 'element-ready-pro' ),
								'relative' => __( 'Relative', 'element-ready-pro' ),
								'static'   => __( 'Static', 'element-ready-pro' ),
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::after' => 'position: {{VALUE}};',
							],
						]
					);
					$this->add_responsive_control(
						'progress_box__after_position_from_left',
						[
							'label'      => __( 'From Left', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::after' => 'left: {{SIZE}}{{UNIT}};',
							],
							'condition' => [
								'progress_box__after_position' => ['absolute','relative']
							],
						]
					);
					$this->add_responsive_control(
						'progress_box__after_position_from_right',
						[
							'label'      => __( 'From Right', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::after' => 'right: {{SIZE}}{{UNIT}};',
							],
							'condition' => [
								'progress_box__after_position' => ['absolute','relative']
							],
						]
					);
					$this->add_responsive_control(
						'progress_box__after_position_from_top',
						[
							'label'      => __( 'From Top', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::after' => 'top: {{SIZE}}{{UNIT}};',
							],
							'condition' => [
								'progress_box__after_position' => ['absolute','relative']
							],
						]
					);
					$this->add_responsive_control(
						'progress_box__after_position_from_bottom',
						[
							'label'      => __( 'From Bottom', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::after' => 'bottom: {{SIZE}}{{UNIT}};',
							],
							'condition' => [
								'progress_box__after_position' => ['absolute','relative']
							],
						]
					);
					$this->add_responsive_control(
						'progress_box__after_align',
						[
							'label'   => __( 'Alignment', 'element-ready-pro' ),
							'type'    => Controls_Manager::CHOOSE,
							'options' => [
								'text-align:left' => [
									'title' => __( 'Left', 'element-ready-pro' ),
									'icon'  => 'fa fa-align-left',
								],
								'margin: 0 auto' => [
									'title' => __( 'Center', 'element-ready-pro' ),
									'icon'  => 'fa fa-align-center',
								],
								'float:right' => [
									'title' => __( 'Right', 'element-ready-pro' ),
									'icon'  => 'fa fa-align-right',
								],
								'text-align:justify' => [
									'title' => __( 'Justify', 'element-ready-pro' ),
									'icon'  => 'fa fa-align-justify',
								],
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::after' => '{{VALUE}};',
							],
							'default' => 'text-align:left',
						]
					);
					$this->add_responsive_control(
						'progress_box__after_width',
						[
							'label'      => __( 'Width', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::after' => 'width: {{SIZE}}{{UNIT}};',
							],
						]
					);
					$this->add_responsive_control(
						'progress_box__after_height',
						[
							'label'      => __( 'Height', 'element-ready-pro' ),
							'type'       => Controls_Manager::SLIDER,
							'size_units' => [ 'px', '%' ],
							'range'      => [
								'px' => [
									'min'  => 0,
									'max'  => 1000,
									'step' => 1,
								],
								'%' => [
									'min' => 0,
									'max' => 100,
								],
							],
							'default' => [
								'unit' => 'px',
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::after' => 'height: {{SIZE}}{{UNIT}};',
							],
						]
					);
					$this->add_control(
						'progress_box__after_opacity',
						[
							'label' => __( 'Opacity', 'element-ready-pro' ),
							'type'  => Controls_Manager::SLIDER,
							'range' => [
								'px' => [
									'max'  => 1,
									'min'  => 0.10,
									'step' => 0.01,
								],
							],
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::after' => 'opacity: {{SIZE}};',
							],
						]
					);
					$this->add_control(
						'progress_box__after_zindex',
						[
							'label'     => __( 'Z-Index', 'element-ready-pro' ),
							'type'      => Controls_Manager::NUMBER,
							'min'       => -99,
							'max'       => 99,
							'step'      => 1,
							'selectors' => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::after' => 'z-index: {{SIZE}};',
							],
						]
					);
					$this->add_responsive_control(
						'progress_box__after_margin',
						[
							'label'      => __( 'Margin', 'element-ready-pro' ),
							'type'       => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%', 'em' ],
							'selectors'  => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::after' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);

					$this->add_responsive_control(
						'progress_box__after_border__radius',
						[
							'label'      => __( 'Border Radius', 'element-ready-pro' ),
							'type'       => Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', '%', 'em' ],
							'selectors'  => [
								'{{WRAPPER}} .element__ready__progressbar__activation .proggress::after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);

				$this->end_controls_tab();
			$this->end_controls_tabs();
		$this->end_controls_section();
	}
	
	protected function render() {

		$settings   = $this->get_settings_for_display();
		$random_id  = $this->get_id();

		$title = '';
		if ( 'yes' == $settings['show_title'] ) {
			$title = $settings['title'];
		}

		$options = array(
			'percentage'          => $settings['percentage']['size'] ? $settings['percentage']['size'] : 70,
			'height'              => $settings['height']['size'] ? $settings['height']['size'] : 20,
			'radius'              => $settings['radius']['size'] ? $settings['radius']['size'] : 0,
			'unit'                => $settings['unit'] ? $settings['unit'] : '%',
			'ShowProgressCount'   => ( 'yes' === $settings['ShowProgressCount'] ) ? true : false,                       // true default
			'animation'           => ( 'yes' === $settings['animation'] ) ? true : false,                               // true default
			'duration'            => $settings['duration']['size'] ? $settings['duration']['size'] : 1000,
			'fillBackgroundColor' => $settings['fillBackgroundColor'] ? $settings['fillBackgroundColor'] : '#3498db',
			'backgroundColor'     => $settings['backgroundColor'] ? $settings['backgroundColor'] : '#EEEEEE',
		);
		$this->add_render_attribute( 'progressbar_attr', 'data-options', json_encode( $options ) );

		$this->add_render_attribute( 'progressbar_wrap_attr', 'data-init', true );
		$this->add_render_attribute( 'progressbar_wrap_attr', 'class', 'element__ready__progressbar__wrap');
		$this->add_render_attribute( 'progressbar_attr', 'class', 'element__ready__progressbar__activation');
		$this->add_render_attribute( 'progressbar_attr', 'id', 'progress'.$random_id );

		?>
			<div <?php echo $this->get_render_attribute_string( 'progressbar_wrap_attr' ); ?>>
				<?php if( $title ) : ?>
				<div class="progressTitle"><?php echo esc_html__( $title ); ?></div>
				<?php endif; ?>
				<div <?php echo $this->get_render_attribute_string( 'progressbar_attr' ); ?>></div>
			</div>
		<?php
	}
}