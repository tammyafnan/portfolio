;(function ($) {
    
    // elementor.hooks.addAction( 'panel/open_editor/widget/slider', function( panel, model, view ) {
    //     var $element = view.$el.find( '.elementor-selector' );
     
    //     if ( $element.length ) {
    //         $element.click( function() {
    //           alert( 'Some Message' );
    //         } );
    //     }
    //  } );

    //  elementor.hooks.addAction( 'panel/open_editor/widget', function( panel, model, view ) {
       
    //    var $element = view.$el.find( '.elementor-selector' );
    //    //view.$el.append('<h3> helow world </h3>');
    //    if ( $element.length ) {
    //        $element.click( function() {
    //          alert( 'Some Message' );
    //        } );
    //    }
    // } );

    
 
})(jQuery);