<?php

/**
 * @package  fallow-essential
 */

namespace FallowEssential\Base;

class Activate
{
	public static function activate()
	{
		flush_rewrite_rules();
	}
}
