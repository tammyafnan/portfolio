<?php

/**
 * @package  quomodo
 */

namespace FallowEssential\Base;

class BaseController
{
	public $plugin_path;

	public $plugin_url;

	public $plugin;

	public function __construct()
	{
		$this->plugin_path = FALLOW_ESSENTIAL_PLUGIN_PATH;
		$this->plugin_url  = FALLOW_ESSENTIAL_PLUGIN_URL;
		$this->plugin      = FALLOW_ESSENTIAL_PLUGIN;
	}
}
