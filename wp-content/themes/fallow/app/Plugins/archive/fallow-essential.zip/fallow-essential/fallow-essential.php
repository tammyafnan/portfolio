<?php
/*
* Plugin Name: Fallow Essentials
* License - GNU/GPL V2 or Later
* Description: This is a essential plugin for Fallow Wordpress theme.
* Version: 1.0.0
* text domain: fallow-essential
*/

// If this file is calledd directly, abort!!!
defined('ABSPATH') or die('Hey, what are you doing here? You silly human!');

// Require once the Composer Autoload
if (file_exists(dirname(__FILE__) . '/vendor/autoload.php')) {
	require_once dirname(__FILE__) . '/vendor/autoload.php';
}
// Require option library
if (file_exists(dirname(__FILE__) . '/app/Framework/codestar-framework.php')) {
	require_once dirname(__FILE__) . '/app/Framework/codestar-framework.php';
}
/** 
 * plugin constant
 */

define('FALLOW_ESSENTIAL_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('FALLOW_ESSENTIAL_PLUGIN_URL', plugin_dir_url(__FILE__));
define('FALLOW_ESSENTIAL_PLUGIN', plugin_basename(dirname(__FILE__)) . '/fallow-essential.php');
define('FALLOW_ESSENTIAL_IMG', get_template_directory_uri() . '/assets/images');

/**
 * The code that runs during plugin activation
 */

function fallow_activate_essential_plugin()
{
	FallowEssential\Base\Activate::activate();
}

register_activation_hook(__FILE__, 'fallow_activate_essential_plugin');

/**
 * The code that runs during plugin deactivation
 */

function fallow_deactivate_essential_plugin()
{
	FallowEssential\Base\Deactivate::deactivate();
}
register_deactivation_hook(__FILE__, 'fallow_deactivate_essential_plugin');

/**
 * Initialize all the core classes of the plugin
 */
if (class_exists('FallowEssential\\Init')) {

	FallowEssential\Init::register_services();
	FallowEssential\Init::register_modules();
}
