<?php

/**
 * @package  fallow-essential
 */

namespace FallowEssential\Base;

use FallowEssential\Base\BaseController;

/**
 * 
 */
class Enqueue extends BaseController
{
	public function register()
	{
	}
}
