<?php

/**
 * @package  fallow-essential
 */

namespace FallowEssential\Utilities;

class Helpers
{
}
